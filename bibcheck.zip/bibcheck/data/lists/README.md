# Quality lists (whitelists, blacklists, rankings)

Drop CSV files into the sub-folders; the file name (without `.csv`) becomes the list name that is
written to `x-whitelists`, `x-blacklists` and `x-rankings`.

Header: `name,issn,publisher,value,valid_from`

* A row with only `publisher` filled in matches every outlet of that publisher (typical for publisher blacklists).
* `valid_from` (year): ranking only counts for publications from that year on.
* Download sources (not bundled – licence/updates are the responsibility of the list owners):
  DOAJ journal CSV (https://doaj.org/docs/journal-csv), Beall's list copies (beallslist.net),
  predatoryjournals.org, SCImago (scimagojr.com), CWTS journal indicators, VHB-JOURQUAL / VHB Rating 2024,
  Clarivate Master Journal List.
* DOAJ and OpenAlex are also queried live, so the DOAJ whitelist works without a CSV.
