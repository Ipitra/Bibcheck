# bibcheck – verify, correct and enrich BibTeX references

Deterministic (no generative AI) checker for BibTeX files, built from the kick-off brief
"Verification and Enrichment of Bibliographic References". Stage 1 is a command-line tool; stage 2 is a thin
web front end (`python -m bibcheck.webapp`) that calls the same pipeline.

## Usage
```bash
pip install -r requirements.txt
python -m bibcheck references.bib --email you@example.org      # writes references.verified.bib + references.report.md
python -m bibcheck references.bib --no-adopt --json out.json   # only fill gaps, also write JSON
python -m unittest discover -s tests                            # offline unit tests
```

## What is checked per entry (brief → implementation)
| Question in the brief | How it is answered |
|---|---|
| DOI/URL present? Can it be found? | DOI field / DOI in URL / arXiv URL; otherwise search Crossref + OpenAlex + DBLP, accept a hit only if title ≥ 0.90 similar, authors' surnames match and year ±1 |
| Does the DOI exist and point to *this* publication? | Crossref, then DataCite (arXiv, Zenodo …); `x-doi-exists`, `x-doi-points-to-the-correct-publication` |
| Publisher/catalogue data matches? Adopt it? | Compared field by field; publisher data is adopted by default (`--no-adopt` to only fill gaps). Old values are kept in `x-original-<field>` |
| Authors | all authors, correct order, full names instead of initials, accents/encodings normalised, titles ("Prof. Dr.") stripped, ORCIDs from Crossref/OpenAlex/DataCite → `x-author-orcids` |
| Outlet | ISSN (print/electronic), exists (Crossref journals), URL (OpenAlex) |
| White/black lists, rankings | DOAJ live; CSV lists in `data/lists/` (see its README). Rankings honour `valid_from` |
| Retracted? When? | Crossref `updated-by` / `updates:` notices (includes Retraction Watch data), OpenAlex `is_retracted`; retraction date → `x-retraction-date` so it can be compared with the citation date |
| Evidence for existence | `x-publication-exists` = Yes/No/Unknown (Unknown = sources unreachable, never "No") |

Output fields follow the sample entry in the brief (`x-…`), plus `x-retraction-date`, `x-retraction-notice-doi`, `x-retraction-reason`, `x-original-*`.

## Known limits (be honest in your write-up)
* **Developed offline:** the sandbox had no internet and the course ZIP (test data, manual-check Excel) was not available, so only unit tests with fake sources ran. **Run it against the three test sets before handing in** and compare with the Excel results.
* `x-found-in-google` is always `n.a.` (Google has no free API; manual interpretation is expected by the brief). A SerpAPI plug-in would be the next step.
* Quality lists are not bundled (licences/currency); fill `data/lists/`. Blacklists work by exact ISSN/name/publisher match.
* Book/ISBN sources (Open Library, Google Books), PubMed, Semantic Scholar, hijacked-journal detection and a proper GUI are not implemented yet.
* Retraction notices dated *after* your citation are flagged by date only; the tool does not know when you cited.
